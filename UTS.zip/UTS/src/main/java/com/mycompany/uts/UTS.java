/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.uts;

/**
 *
 * @author Leyli Agustin
 */
public class UTS {

    public static void main(String[] args) {
    }
}
